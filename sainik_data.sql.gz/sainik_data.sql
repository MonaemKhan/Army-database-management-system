-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2019 at 05:23 AM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sainik_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `approve`
--

CREATE TABLE `approve` (
  `application` int(20) NOT NULL,
  `id` varchar(10) DEFAULT NULL,
  `Name` varchar(33) DEFAULT NULL,
  `rank` varchar(25) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `from` varchar(10) NOT NULL,
  `to` varchar(10) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `dis` varchar(5) DEFAULT NULL,
  `date` varchar(25) DEFAULT NULL,
  `issu date` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `approve`
--

INSERT INTO `approve` (`application`, `id`, `Name`, `rank`, `unit`, `from`, `to`, `reason`, `dis`, `date`, `issu date`) VALUES
(18, 'SNK-01', 'Md: Abu Sama', 'Lieutenant', NULL, '4-08-2019', '17-08-2019', '', 'No', '04-08-2019', '04-08-2019 10:21:24'),
(19, 'SNK-43', 'Md: Abu Sama', 'Lieutenant', NULL, '11', '22', '', 'No', '04-08-2019', '04-08-2019 11:09:18'),
(20, 'SNK-43', 'Md: Abu Sama', 'Lieutenant', NULL, 'ds', 'dsgb', 'dg', 'No', '04-08-2019', '04-08-2019 11:09:18'),
(21, 'SNK-43', 'Md: Abu Sama', 'Lieutenant', NULL, '04-08-2019', '17-08-2019', 'Eid-Ul-Azha', 'Yes', '04-08-2019', '04-08-2019 11:09:18'),
(22, 'SNK-43', 'Md: Abu Sama', 'Lieutenant', NULL, '10-08-2019', '13-08-2019', 'eid-ul-adha', 'Yes', '04-08-2019', '04-08-2019 11:09:18'),
(23, 'SNK-43', 'MD: Abu Sama', 'Captain', NULL, '4-8-19', '20-8-19', 'Amar Beya sir!!', 'Yes', '04-08-2019', '04-08-2019 11:17:24'),
(24, 'SNK-43', 'MD: Abu Sama', 'Captain', NULL, '4-8-19', '18-8-19', 'Eid', 'Yes', '04-08-2019', '04-08-2019 07:15:24'),
(25, 'SNK-43', 'MD: Abu Sama', 'Captain', NULL, '05-08-2019', '10-08-2019', 'Mother illness', 'Yes', '05-08-2019', '05-08-2019 09:58:52'),
(26, 'SNK-43', 'MD: Abu Sama', 'Captain', NULL, '05-08-2019', '10-08-2019', 'Relaxation', 'Yes', '05-08-2019', '05-08-2019 11:38:20'),
(27, 'SNK-21', 'Saharab Hossain Sojib', 'Lieutenant colonel', NULL, 'sgdnsg', 'dshsh', 'etdgdgdbd', NULL, '09-09-2019', NULL),
(28, 'SNK-21', 'Saharab Hossain Sojib', 'Lieutenant colonel', NULL, 'strhs', 'fnsf', 'bsfgb', NULL, '09-09-2019', NULL),
(29, 'SNK-21', 'Saharab Hossain Sojib', 'Lieutenant colonel', NULL, 'kdsjsd', 'dakkjad', 'sfv', 'Yes', '09-09-2019', '09-09-2019 11:03:15'),
(30, 'SNK-01', 'MR. Rahat Akanda', 'Colonel', NULL, '11-08-2019', '17-08-2019', 'Nothing', NULL, '09-09-2019', NULL),
(31, 'SNK-43', 'MD Abu Sama', 'Second lieutenant', NULL, '11-09-2019', '18-09-2019', 'Need A Break From My \nWorking Life', 'Yes', '10-09-2019', '10-09-2019 04:13:39');

-- --------------------------------------------------------

--
-- Table structure for table `id`
--

CREATE TABLE `id` (
  `num` int(2) DEFAULT NULL,
  `idp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `id`
--

INSERT INTO `id` (`num`, `idp`) VALUES
(0, 'SNK-43');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` varchar(10) NOT NULL,
  `img` varchar(100) DEFAULT NULL,
  `password` varchar(33) DEFAULT NULL,
  `name` varchar(33) DEFAULT NULL,
  `father` varchar(33) DEFAULT NULL,
  `mother` varchar(33) DEFAULT NULL,
  `phn` varchar(15) DEFAULT NULL,
  `home` varchar(20) DEFAULT NULL,
  `gender` varchar(7) DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `national` varchar(10) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `dob` varchar(10) DEFAULT NULL,
  `blood` varchar(4) DEFAULT NULL,
  `core` varchar(25) DEFAULT NULL,
  `rank` varchar(25) DEFAULT NULL,
  `region` varchar(25) DEFAULT NULL,
  `unit` varchar(25) DEFAULT NULL,
  `join` varchar(10) DEFAULT NULL,
  `apli_id` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `img`, `password`, `name`, `father`, `mother`, `phn`, `home`, `gender`, `email`, `national`, `address`, `dob`, `blood`, `core`, `rank`, `region`, `unit`, `join`, `apli_id`) VALUES
('SNK-01', 'C:\\Users\\MONAEM\\Desktop\\rahat.jpg', '1234', 'MR. Rahat Akanda', 'uuuuuu', 'yyyyyyy', '+8801598766', 'Chittagong', 'Male', 'rahat_pada@gmail.com', '414222428', 'Not Satteled Yet', '21-01-1997', 'O+', 'EME', 'Colonel', 'Bandarban Cantonment', '12 Field Battary', '04-08-2019', 30),
('SNK-12', 'C:\\Users\\MONAEM\\Desktop\\sama.jpg', NULL, 'Md Abu Sama', 'aaaa', 'aaaaa', '+8801832233593', 'Rangamati', 'Male', 'abusama@gmail.com', '12334567', 'Langadu , Rangamati', '24-10-1997', 'O-', 'EME', 'Captain', 'Chittagong Cantonment', '121 w&c', '05-08-2019', NULL),
('SNK-40', 'C:\\Users\\MONAEM\\Desktop\\u mong.jpg', NULL, 'U Mong Shing Marma', 'ggghh', 'fhnhfn', '+880155', 'Bandarban', 'Male', 'umong_the_bot@gmail.com', '8959558', 'Lama , Bandarban', '21-08-1998', 'AB+', 'EME', 'Lieutenant general', 'Bandarban Cantonment', '12 Field Battart', '04-08-2019', NULL),
('SNK-43', 'C:\\Users\\MONAEM\\Desktop\\sama.jpg', '1234', 'MD Abu Sama', 'Mr. X', 'Mrs. X', '+88015........', 'Rangamati', 'Male', 'Abusama43@gmail.com', '256254258', 'BaibanSara,Langadu,Rangamati', '24-10-1997', 'O-', 'EME', 'Second lieutenant', 'Khagrachori Cantonment', 'Artilary Head Quater', '10-09-2019', 31),
('SNK-48', 'C:\\Users\\MONAEM\\Desktop\\mamun.jpg', NULL, 'Mohammad Al Mamun', 'tttttt', 'fffffff', '+88017', 'Khagrachori', 'Male', 'mamun_1st_boy@gmail.com', '29598595', 'Notun Para , Matiranga , Khagrachori', '3-9-1998', 'B+', 'EME', 'General', 'Bandarban Cantonment', '12 Field Battart', '04-08-2019', NULL),
('SNK-50', 'C:\\Users\\MONAEM\\Desktop\\sama.jpg', NULL, 'Prosenjit Chockrobort anik', 'aaaaa', 'ssssss', '+88018', 'Rangamati', 'Male', 'prosenjit50@gmail.com', '234455466', 'Rajostholi , Rangamati', '17-07-1998', 'O+', 'EME', 'Lieutenant', 'Bandarban Cantonment', '12 Field Battart', '04-08-2019', NULL),
('SNK-53', 'C:\\Users\\MONAEM\\Desktop\\apu.jpg', NULL, 'SM. Golam Sarwar Apu', 'qqqqqq', 'wwwww', '+880193', 'Rangamati', 'Male', 'smgapu53@gmail.com', '6543563476', 'Mohila College Road , Rangamati', '1-8-1998', 'A+', 'EME', 'Captain', 'Bandarban Cantonment', '12 Field Battart', '04-08-2019', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `id` varchar(10) NOT NULL,
  `Name` varchar(33) NOT NULL,
  `rank` varchar(25) NOT NULL,
  `unit` varchar(25) NOT NULL,
  `msg` varchar(300) NOT NULL,
  `date` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `Name`, `rank`, `unit`, `msg`, `date`) VALUES
('SNK-43', 'Md: Abu Sama', 'Lieutenant', '12 Field Battary', 'Fix my date of birth & join date', '04-08-2019'),
('SNK-43', 'Md: Abu Sama', 'Lieutenant', '12 Field Battary', 'i don\'t see my photo fix it.', '04-08-2019'),
('SNK-43', 'MD: Abu Sama', 'Captain', '12 Field Battary', 'Thanks for fixed my problem.', '04-08-2019'),
('SNK-43', 'MD: Abu Sama', 'Captain', '12 Field Battary', 'My Name IS error', '04-08-2019'),
('SNK-43', 'MD: Abu Sama', 'Captain', '12 Field Battary', 'Change My BirthDate It\'s 24-10-1996', '05-08-2019'),
('SNK-43', 'MD: Abu Sama', 'Captain', '12 Field Battary', 'Change My Name', '05-08-2019'),
('SNK-43', 'MD Abu Sama', 'Second lieutenant', 'Artilary Head Quater', 'Change My Date Of Birth new DOB Is :24-10-1996', '10-09-2019');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approve`
--
ALTER TABLE `approve`
  ADD PRIMARY KEY (`application`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approve`
--
ALTER TABLE `approve`
  MODIFY `application` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
